/**
 * Created by leibo on 18/3/29.
 */
export default {
  ticketAttractionsList: [],//景点信息
  themeTypeList: [],//查询景点主题分类信息
  ticketGreatList: [],//洲
  ticketCountrieList: [],//国家
  ticketProviceList: [],//省
  ticketCityList: [],//市
  ticketContryList: [],//县
  updateTicketAttractionsObj: {},//修改商家信息
  predeterminedInstructionsList: [],//预定须知
  updatePredeterminedInstructionsObj: {},//修改预定须知
  trafficInformationList: [],//交通信息
  updateTrafficInformationObj: {},//修改交通信息
  ticketTypeList: [],//票种类型
  updateTicketTypeObj: {},//修改票种类型
  ticketTypeTicketPriceList: [],//票种票价数据
  ticketQueryOrderList: [],//商户订单信息数据
  ticketMapList:[],//导图
}
