export default {

  foodStoreInformtionList: [], //房间信息

  foodStoreInformtionList1: [], //房间信息

  numberOfMealsList: [],//用餐人数类型

  storefrontTypeList: [],//店面类型

  foodProcinceList: [], // 省

  foodCityList: [],//市

  foodStoreRoomList: [],//店面房间

  foodStoreProductList: [],//店面产品
/**************************停车场*****************************************/
  foodStoppingPlaceList: [],//停车场

  foodStoppingPlaceStoreAllList:[],//停车场里所有店面信息

  foodRoomPictureList: [],//店面房间图片

  foodProductPictureList: [],//店面图片

  foodStoreRoomTabelList: [],//店面餐桌

  foodStoreRecommendList: [],//推荐菜

  foodStoreTableTimeList: [],//店面每天可锁桌时间

  foodStoreOrderingTimeList: [],//店面可订餐时间

  foodStoreConfirnOrderList: [],//订单列表

  foodStoreProductPictureList: [],//店面菜肴图片



}
