/**
 * Created by liuxiang on 18/05/03.
 */
export default {
  VMovieCheckTableList: [],//微电影审核表信息
  VMovieSeries: [],//微电影系列
  VMovieVideoSeries: [],//微电影视频系列
  VMovieVideoList: [],//微电影视频
  VMovieMiniVideoList: [],//微电影微电影
  VMovieVideoCategoriesList: [],//微电影视频分类
  VMovieVideoSeriesCategoriesList: [],//微电影系列分类
  VMovieTypeList: [],//微电影列分类
  UploadVideoList: [],//微电影上传电影
  VMovieParentTypeList: [],//微电影父分类
  VMovieChildTyeList: [],//微电影子分类
  VMovieChildTyeList2: [],//微电影子分类

}
