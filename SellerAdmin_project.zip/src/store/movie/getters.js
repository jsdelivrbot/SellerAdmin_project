/**
 * Created by liuxiang on 18/05/03.
 */
export default {
  VMovieCheckTableList: state => state.VMovieCheckTableList,
  VMovieSeries: state => state.VMovieSeries,
  VMovieVideoSeries: state => state.VMovieVideoSeries,
  VMovieVideoList: state => state.VMovieVideoList,
  VMovieMiniVideoList: state => state.VMovieMiniVideoList,
  VMovieVideoCategoriesList: state => state.VMovieVideoCategoriesList,
  VMovieVideoSeriesCategoriesList: state => state.VMovieVideoSeriesCategoriesList,
  VMovieTypeList: state => state.VMovieTypeList,
  UploadVideoList: state => state.UploadVideoList,
  VMovieParentTypeList: state => state.VMovieParentTypeList,
  VMovieChildTyeList: state => state.VMovieChildTyeList,
  VMovieChildTyeList2: state => state.VMovieChildTyeList2,

}
