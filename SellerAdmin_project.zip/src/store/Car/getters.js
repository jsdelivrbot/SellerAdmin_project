/**
 * Created by leibo on 18/4/25.
 */
export default {
  carCompaniesList: state => state.carCompaniesList,
  carStoreList: state => state.carStoreList,
  carGetCityLandmarkInfoList: state => state.carGetCityLandmarkInfoList,
  carProductList: state => state.carProductList,
  carCompanyCarList: state => state.carCompanyCarList,
  carCompanyCarStoreList: state => state.carCompanyCarStoreList,
  carPreferentialPoliciesList: state => state.carPreferentialPoliciesList,
  carOrderDetailsList: state => state.carOrderDetailsList,
}


