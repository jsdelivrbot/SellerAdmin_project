/**
 * Created by leibo on 18/4/25.
 */
export default {
  carCompaniesList:[],//供应商租车公司
  carStoreList:[],//门店
  carGetCityLandmarkInfoList:[],//城市地标
  carProductList:[],//汽车产品
  carCompanyCarList:[],//公司汽车
  carCompanyCarStoreList:[],//公司汽车用到所有门店
  carPreferentialPoliciesList:[],//优惠政策
  carOrderDetailsList:[],//订单
}
