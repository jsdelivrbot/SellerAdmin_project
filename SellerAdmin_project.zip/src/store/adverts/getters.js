/**
 * Created by liuxiang on 18/3/30.
 */
export default {
  /********************************************广告申请*********************************************************/
  adApplyList: state => state.adApplyList,
  updateAdApplyObj: state => state.updateAdApplyObj,
  adPositionAllList: state => state.adPositionAllList,
  adTypeApplyAllList: state => state.adTypeApplyAllList,

}
