/**
 * Created by leibo on 18/3/29.
 */
export default {
  ticketAttractionsList: state => state.ticketAttractionsList,
  themeTypeList: state => state.themeTypeList,
  ticketGreatList: state => state.ticketGreatList,
  ticketCountrieList: state => state.ticketCountrieList,
  ticketProviceList: state => state.ticketProviceList,
  ticketCityList: state => state.ticketCityList,
  ticketContryList: state => state.ticketContryList,
  updateTicketAttractionsObj: state => state.updateTicketAttractionsObj,
  predeterminedInstructionsList: state => state.predeterminedInstructionsList,
  updatePredeterminedInstructionsObj: state => state.updatePredeterminedInstructionsObj,
  trafficInformationList: state => state.trafficInformationList,
  updateTrafficInformationObj: state => state.updateTrafficInformationObj,
  ticketTypeList: state => state.ticketTypeList,
  updateTicketTypeObj: state => state.updateTicketTypeObj,

  ticketTypeTicketPriceList: state => state.ticketTypeTicketPriceList,
  ticketQueryOrderList: state => state.ticketQueryOrderList,
  ticketMapList: state => state.ticketMapList,
 // ToggleDevice: state => state.ToggleDevice,
  //参数
  //门票


}
