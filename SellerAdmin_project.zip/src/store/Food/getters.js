export default {
  foodStoreInformtionList: state => state.foodStoreInformtionList,
  foodStoreInformtionList1: state => state.foodStoreInformtionList1,
  numberOfMealsList: state => state.numberOfMealsList,
  storefrontTypeList: state => state.storefrontTypeList,
  foodProcinceList: state => state.foodProcinceList,
  foodCityList: state => state.foodCityList,
  foodStoreRoomList: state => state.foodStoreRoomList,
  foodStoreProductList: state => state.foodStoreProductList,

  foodRoomPictureList: state => state.foodRoomPictureList,
  foodProductPictureList: state => state.foodProductPictureList,
  foodStoreRoomTabelList: state => state.foodStoreRoomTabelList,
  foodStoreRecommendList: state => state.foodStoreRecommendList,
  foodStoreTableTimeList: state => state.foodStoreTableTimeList,
  foodStoreOrderingTimeList: state => state.foodStoreOrderingTimeList,
  foodStoreConfirnOrderList: state => state.foodStoreConfirnOrderList,
  foodStoreProductPictureList: state => state.foodStoreProductPictureList,
  foodStoppingPlaceList: state => state.foodStoppingPlaceList,


}

















