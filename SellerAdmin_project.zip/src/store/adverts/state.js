/**
 * Created by LiuXiang on 18/04/09.
 */
export default {
  /********************************************广告申请*********************************************************/
  adApplyList: [],//广告位置
  updateAdApplyObj: {},//修改广告申请obj
  adPositionAllList: [],//广告位置//广告申请中获取所有广告位置
  adTypeApplyAllList: [],//广告位置//广告申请中获取所有广告类型
}
